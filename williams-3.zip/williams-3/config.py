# Austin Williams
# Dr. Shawn Butler
# Computer Networks
# November 25, 2020

TIMEOUT = 20
VERBOSE = False
MAX_PACKET_SIZE = 516
